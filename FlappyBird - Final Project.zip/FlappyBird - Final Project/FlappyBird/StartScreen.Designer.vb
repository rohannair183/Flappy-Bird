﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class StartScreen
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.STartScreenMessageLabel = New System.Windows.Forms.Label()
        Me.Ground = New System.Windows.Forms.PictureBox()
        CType(Me.Ground, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'STartScreenMessageLabel
        '
        Me.STartScreenMessageLabel.AutoSize = True
        Me.STartScreenMessageLabel.BackColor = System.Drawing.Color.Transparent
        Me.STartScreenMessageLabel.Font = New System.Drawing.Font("Cooper Black", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.STartScreenMessageLabel.Location = New System.Drawing.Point(84, 347)
        Me.STartScreenMessageLabel.Name = "STartScreenMessageLabel"
        Me.STartScreenMessageLabel.Size = New System.Drawing.Size(294, 21)
        Me.STartScreenMessageLabel.TabIndex = 2
        Me.STartScreenMessageLabel.Text = "Press space to start playing..."
        '
        'Ground
        '
        Me.Ground.BackgroundImage = Global.FlappyBird.My.Resources.Resources.FlappyBirdground
        Me.Ground.Location = New System.Drawing.Point(-9, 371)
        Me.Ground.Name = "Ground"
        Me.Ground.Size = New System.Drawing.Size(500, 50)
        Me.Ground.TabIndex = 3
        Me.Ground.TabStop = False
        '
        'StartScreen
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.FlappyBird.My.Resources.Resources.editedFlappyBirdBackground
        Me.ClientSize = New System.Drawing.Size(484, 411)
        Me.Controls.Add(Me.STartScreenMessageLabel)
        Me.Controls.Add(Me.Ground)
        Me.Name = "StartScreen"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "   Start Screen"
        CType(Me.Ground, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents STartScreenMessageLabel As Label
    Friend WithEvents Ground As PictureBox
End Class
