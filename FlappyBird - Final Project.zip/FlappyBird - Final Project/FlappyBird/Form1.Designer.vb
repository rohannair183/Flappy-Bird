﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FlappyBird
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.GameTimer = New System.Windows.Forms.Timer(Me.components)
        Me.ScoreLabel = New System.Windows.Forms.Label()
        Me.Ground = New System.Windows.Forms.PictureBox()
        Me.Bird = New System.Windows.Forms.PictureBox()
        Me.MedalPictureBox = New System.Windows.Forms.PictureBox()
        Me.BestScoreLabel = New System.Windows.Forms.Label()
        Me.EndScoreLabel = New System.Windows.Forms.Label()
        Me.EndScoreDisplay = New System.Windows.Forms.PictureBox()
        Me.InstructionLabel = New System.Windows.Forms.Label()
        CType(Me.Ground, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Bird, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MedalPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EndScoreDisplay, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GameTimer
        '
        '
        'ScoreLabel
        '
        Me.ScoreLabel.AutoSize = True
        Me.ScoreLabel.BackColor = System.Drawing.Color.Transparent
        Me.ScoreLabel.Font = New System.Drawing.Font("Cooper Black", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ScoreLabel.ForeColor = System.Drawing.Color.White
        Me.ScoreLabel.Location = New System.Drawing.Point(202, 9)
        Me.ScoreLabel.Name = "ScoreLabel"
        Me.ScoreLabel.Size = New System.Drawing.Size(70, 74)
        Me.ScoreLabel.TabIndex = 1
        Me.ScoreLabel.Text = "0"
        '
        'Ground
        '
        Me.Ground.BackgroundImage = Global.FlappyBird.My.Resources.Resources.FlappyBirdground
        Me.Ground.Location = New System.Drawing.Point(0, 386)
        Me.Ground.Name = "Ground"
        Me.Ground.Size = New System.Drawing.Size(632, 50)
        Me.Ground.TabIndex = 2
        Me.Ground.TabStop = False
        '
        'Bird
        '
        Me.Bird.BackColor = System.Drawing.Color.Transparent
        Me.Bird.BackgroundImage = Global.FlappyBird.My.Resources.Resources.FlappyBird
        Me.Bird.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Bird.Location = New System.Drawing.Point(50, 80)
        Me.Bird.Name = "Bird"
        Me.Bird.Size = New System.Drawing.Size(44, 36)
        Me.Bird.TabIndex = 0
        Me.Bird.TabStop = False
        '
        'MedalPictureBox
        '
        Me.MedalPictureBox.BackColor = System.Drawing.Color.Khaki
        Me.MedalPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.MedalPictureBox.Location = New System.Drawing.Point(81, 174)
        Me.MedalPictureBox.Name = "MedalPictureBox"
        Me.MedalPictureBox.Size = New System.Drawing.Size(90, 86)
        Me.MedalPictureBox.TabIndex = 10
        Me.MedalPictureBox.TabStop = False
        Me.MedalPictureBox.Visible = False
        '
        'BestScoreLabel
        '
        Me.BestScoreLabel.AutoSize = True
        Me.BestScoreLabel.BackColor = System.Drawing.Color.LemonChiffon
        Me.BestScoreLabel.Font = New System.Drawing.Font("Cooper Black", 24.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BestScoreLabel.ForeColor = System.Drawing.Color.White
        Me.BestScoreLabel.Image = Global.FlappyBird.My.Resources.Resources.score
        Me.BestScoreLabel.Location = New System.Drawing.Point(341, 245)
        Me.BestScoreLabel.Name = "BestScoreLabel"
        Me.BestScoreLabel.Size = New System.Drawing.Size(34, 36)
        Me.BestScoreLabel.TabIndex = 9
        Me.BestScoreLabel.Text = "0"
        Me.BestScoreLabel.Visible = False
        '
        'EndScoreLabel
        '
        Me.EndScoreLabel.AutoSize = True
        Me.EndScoreLabel.BackColor = System.Drawing.Color.LemonChiffon
        Me.EndScoreLabel.Font = New System.Drawing.Font("Cooper Black", 24.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EndScoreLabel.ForeColor = System.Drawing.Color.White
        Me.EndScoreLabel.Image = Global.FlappyBird.My.Resources.Resources.score
        Me.EndScoreLabel.Location = New System.Drawing.Point(341, 164)
        Me.EndScoreLabel.Name = "EndScoreLabel"
        Me.EndScoreLabel.Size = New System.Drawing.Size(34, 36)
        Me.EndScoreLabel.TabIndex = 8
        Me.EndScoreLabel.Text = "0"
        Me.EndScoreLabel.Visible = False
        '
        'EndScoreDisplay
        '
        Me.EndScoreDisplay.BackColor = System.Drawing.Color.Transparent
        Me.EndScoreDisplay.BackgroundImage = Global.FlappyBird.My.Resources.Resources.score
        Me.EndScoreDisplay.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.EndScoreDisplay.Location = New System.Drawing.Point(50, 80)
        Me.EndScoreDisplay.Name = "EndScoreDisplay"
        Me.EndScoreDisplay.Size = New System.Drawing.Size(384, 251)
        Me.EndScoreDisplay.TabIndex = 7
        Me.EndScoreDisplay.TabStop = False
        Me.EndScoreDisplay.Visible = False
        '
        'InstructionLabel
        '
        Me.InstructionLabel.AutoSize = True
        Me.InstructionLabel.BackColor = System.Drawing.Color.Transparent
        Me.InstructionLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InstructionLabel.ForeColor = System.Drawing.Color.Black
        Me.InstructionLabel.Location = New System.Drawing.Point(143, 334)
        Me.InstructionLabel.Name = "InstructionLabel"
        Me.InstructionLabel.Size = New System.Drawing.Size(203, 24)
        Me.InstructionLabel.TabIndex = 11
        Me.InstructionLabel.Text = "Press Space to Jump..."
        '
        'FlappyBird
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImage = Global.FlappyBird.My.Resources.Resources.editedFlappyBirdBackground
        Me.ClientSize = New System.Drawing.Size(484, 411)
        Me.Controls.Add(Me.InstructionLabel)
        Me.Controls.Add(Me.MedalPictureBox)
        Me.Controls.Add(Me.BestScoreLabel)
        Me.Controls.Add(Me.EndScoreLabel)
        Me.Controls.Add(Me.EndScoreDisplay)
        Me.Controls.Add(Me.Ground)
        Me.Controls.Add(Me.ScoreLabel)
        Me.Controls.Add(Me.Bird)
        Me.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "FlappyBird"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Flappy Bird"
        CType(Me.Ground, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Bird, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MedalPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EndScoreDisplay, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Bird As PictureBox
    Friend WithEvents GameTimer As Timer
    Friend WithEvents ScoreLabel As Label
    Friend WithEvents Ground As PictureBox
    Friend WithEvents MedalPictureBox As PictureBox
    Friend WithEvents BestScoreLabel As Label
    Friend WithEvents EndScoreLabel As Label
    Friend WithEvents EndScoreDisplay As PictureBox
    Friend WithEvents InstructionLabel As Label
End Class
