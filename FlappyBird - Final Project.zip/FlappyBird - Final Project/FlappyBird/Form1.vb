﻿Public Class FlappyBird

    ' ************************
    ' Flappy Bird      *|-/||*
    ' Rohan Nair       *|-/||*
    ' Comp Sci 20      *|-/||*
    ' Final Project    *|-/||*
    ' October 2020     *|-/||*
    '*************************

    Dim Birdloc As Point ' Var for bird location
    Dim birdSpeed As Decimal = 0 ' Var for bird speed
    Dim gravity As Decimal = 7 ' Var for gravity
    Dim PipeGap As Integer = 480 ' Var for the ap between the top and bottom pipes
    Dim PipeSpeed As Decimal = 9 '  Var for the speed at which the pipes move to the left
    Dim BottomPipes(2), TopPipes(2) As PictureBox ' Var for all the pipes
    Dim Score, HighScore As Integer ' Var that Keeps track of score
    Dim GameOver As Boolean = False ' Var keeps track if the game is over

    Private Sub FlappyBird_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Randomize() 'Randomize all the how the Rnd() funcion operates
        BottomPipe_Creator(1) ' Creates Bottom Pipes with a bit of randomization every game
        TopPipe_Creator(1) ' Creates Top pipes according to the bottom pipes
#Region "The order in which evrthing shows up on the screen"
        MedalPictureBox.Visible = True
        EndScoreLabel.Visible = True ' Make the final score visible
        BestScoreLabel.Visible = True ' make the highscore visible
        EndScoreDisplay.Visible = True ' Make the endscore display(the image) visible
        MedalPictureBox.Visible = False
        EndScoreLabel.Visible = False ' Make the final score visible
        BestScoreLabel.Visible = False ' make the highscore visible
        EndScoreDisplay.Visible = False ' Make the endscore display(the image) visible
#End Region ' If this is taken away for some reason the medal goes behind the score image for some reason
    End Sub

    ' Creates all bottom pipes
    Sub BottomPipe_Creator(number) ' Creates pipes on the screen
        For i = 0 To number
            Dim Pipe As New PictureBox ' Create a new var that is recreated each time this loop is called 
            Me.Controls.Add(Pipe) ' Add this variable to the form
            Pipe.Width = 50 ' Adjust the width
            Pipe.Height = 350  ' Adjust the height
            Pipe.Top = 150 + 150 * Rnd()
            Pipe.Left = (i * 300) + 600
            Pipe.BackgroundImage = My.Resources.BottomPipe ' Image that we use for th pipes
            Pipe.BackgroundImageLayout = ImageLayout.Stretch ' Changing the Image Layout
            Pipe.Visible = True ' Making the visibilty property for the pipe to true
            BottomPipes(i) = Pipe ' Add pipe to the picturebox AllPipes
        Next
    End Sub

    ' Creates all top pipes
    Sub TopPipe_Creator(number) ' Creates pipes on the screen
        For i = 0 To number
            Dim Pipe As New PictureBox ' Create a new var that is recreated each time this loop is called 
            Me.Controls.Add(Pipe) ' Add this variable to the form
            Pipe.Width = 50 ' Adjust the width
            Pipe.Height = 350  ' Adjust the height
            Pipe.Top = BottomPipes(i).Top - PipeGap
            Pipe.Left = (i * 300) + 600
            Pipe.BackgroundImage = My.Resources.TopPipe ' Image that we use for th pipes
            Pipe.BackgroundImageLayout = ImageLayout.Stretch ' Changing the Image Layout
            Pipe.Visible = True ' Making the visibilty property for the pipe to true
            TopPipes(i) = Pipe ' Add pipe to the picturebox AllPipes
        Next
    End Sub

    ' Game Timer handels all movement in the game
    Private Sub GameTimer_Tick(sender As Object, e As EventArgs) Handles GameTimer.Tick
        birdSpeed += gravity ' Add garvity to the bird speed
        Birdloc = New Point(Bird.Location.X, Bird.Location.Y + birdSpeed) ' Change birdloc y by the birdSpeed
        Bird.Location = Birdloc ' Update location
        For i = 0 To 1
            BottomPipes(i).Left -= PipeSpeed ' Moving the bottom pipes by the pipespeed
            TopPipes(i).Left -= PipeSpeed ' Moving the top pipes by pipespeed
            Ground.Left -= PipeSpeed / 2 ' Moving the ground by half the speed of the pipes
            Ground.Width += PipeSpeed ' Add pipespeed to the width of the ground so it doesn't go off the screen
            If (Bird.Location.Y - Bird.Height - 20 >= Ground.Location.Y) Or (Bird.Top < 0 - (Bird.Height * 3)) Or (Bird.Bounds.IntersectsWith(TopPipes(i).Bounds)) Or (Bird.Bounds.IntersectsWith(BottomPipes(i).Bounds)) Then ' Checking all the conditions where the game must end

                For j = 0 To 1 ' Making all the pipes disappear if the game is over
                    TopPipes(j).Visible = False ' invisible top pipe
                    BottomPipes(j).Visible = False ' invisiable bottom pipe
                Next

                If Score > HighScore Then ' Checking is current score is higher than previous highscore
                    HighScore = Score ' if true than the current score is the new highscore
                End If

                If HighScore >= 10 And HighScore <= 19 Then
                    MedalPictureBox.BackgroundImage = My.Resources.Bronze_Medalspng ' Changing Image to bronze
                    MedalPictureBox.BackgroundImageLayout = ImageLayout.Stretch ' Changine Layout to strech
                    MedalPictureBox.Visible = True ' Making Image visible
                ElseIf HighScore >= 20 And HighScore <= 29 Then
                    MedalPictureBox.BackgroundImage = My.Resources.SilverMedal ' Changing Image to silver
                    MedalPictureBox.BackgroundImageLayout = ImageLayout.Stretch ' Changine Layout to strech
                    MedalPictureBox.Visible = True ' Making Image visible
                ElseIf HighScore >= 30 And HighScore <= 39 Then
                    MedalPictureBox.BackgroundImage = My.Resources.GoldMedal ' Changing Image to gold
                    MedalPictureBox.BackgroundImageLayout = ImageLayout.Stretch ' Changine Layout to strech
                    MedalPictureBox.Visible = True ' Making Image visible
                ElseIf HighScore >= 40 Then
                    MedalPictureBox.BackgroundImage = My.Resources.Platinummedal ' Changing Image to platinum
                    MedalPictureBox.BackgroundImageLayout = ImageLayout.Stretch ' Changine Layout to strech
                    MedalPictureBox.Visible = True ' Making Image visible
                End If

                EndScoreLabel.Visible = True ' Make the final score visible
                BestScoreLabel.Visible = True ' make the highscore visible
                EndScoreDisplay.Visible = True ' Make the endscore display(the image) visible
                EndScoreLabel.Text = Val(Score) ' The final score = the value of score


                BestScoreLabel.Text = Val(HighScore) ' Highscorelabel is the value Highscore var
                Score = 0 ' Set the score back to 0
                GameOver = True ' Set gameover to true
                GameTimer.Enabled = False ' Disable the game timer to stop all movement
                Exit For
            End If

            If (Bird.Location.X > TopPipes(i).Location.X + TopPipes(i).Width) And (Bird.Location.X < TopPipes(i).Location.X + TopPipes(i).Width + 10) Then ' Checking if the bird has passed the pipes
                Score += 1 'Add one to the score
                ScoreLabel.Text = Val(Score) ' The label for score is equal to the value of the variable for score

            End If
            If BottomPipes(i).Left < (0 - BottomPipes(i).Width - 20) Then ' Checking if the bottom pipe has gone of the screen
                BottomPipes(i).Top = 150 + 150 * Rnd() ' Generate a new Y location for the bottom pipe
                BottomPipes(i).Left += 600 ' Move the X pipe by 600
                TopPipes(i).Top = BottomPipes(i).Top - PipeGap ' Set toppipe Y = to bottompipe y - PipeGap
                TopPipes(i).Left += 600 ' Move the toppipe locaiton by 600
            End If
        Next
    End Sub

    ' Gets all key down events
    Private Sub FlappyBird_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Space Then ' If space is pressed 
            birdSpeed = -30 ' Set speed to -15
        End If

        If GameOver = True And e.KeyCode = Keys.Space Then ' When game is over and a key is pressed
            EndScoreLabel.Visible = False ' Make invisible
            BestScoreLabel.Visible = False ' Make invisible
            EndScoreDisplay.Visible = False ' Make invisible
            MedalPictureBox.Visible = False
            ScoreLabel.Text = Score ' Update score to 0(Score varible was set to zero)

            BottomPipe_Creator(1) ' Create new bottom pipes
            TopPipe_Creator(1) ' Create new top pipes
            Bird.Top = 60 + 40 * Rnd() ' Create new random bird y location
            Bird.Left = 50 ' Set Bird X location to 50
            GameTimer.Enabled = True ' Enable game timer to allow movement
            GameOver = False ' Set gameover to false
        Else
            GameTimer.Enabled = True ' For the begenninng of the game staring only when a key is pressed
            InstructionLabel.Visible = False ' Taking away instruction when a key is pressed
        End If

    End Sub

    ' Executes when form is closed
    Private Sub FlappyBird_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        StartScreen.Close() ' When this form is closed close the original form so everthing is closed
    End Sub
End Class
