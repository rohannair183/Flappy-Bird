﻿Public Class StartScreen
    ' ************************
    ' Flappy Bird      *|-/||*
    ' Rohan Nair       *|-/||*
    ' Comp Sci 20      *|-/||*
    ' Final Project    *|-/||*
    ' October 2020     *|-/||*
    '*************************

    Private Sub StartScreen_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Space Then
            FlappyBird.Show()
            Me.Hide()
        End If
    End Sub

    Private Sub StartScreen_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class